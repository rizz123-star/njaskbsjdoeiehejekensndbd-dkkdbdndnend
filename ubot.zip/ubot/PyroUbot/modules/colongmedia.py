__MODULE__ = "ᴄᴏʟᴏɴɢ ᴍᴇᴅɪᴀ"
__HELP__ = """
<blockquote><b>♛ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴏʟᴏɴɢ ᴍᴇᴅɪᴀ ♛<b>

<blockquote><b>perintah : 
<code>{0}colong</code> untuk mengambi fidio/foto yang dikirim 1x lihat, contoh penggunaan: .colong (reply foto yang dikirim 1x lihat)</b></blockquote>
"""
