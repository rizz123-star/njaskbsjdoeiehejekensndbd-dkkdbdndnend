import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴄᴇᴋ ʀᴀᴍʙᴜᴛ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Cek Rambut</b>

Perintah:
<code>.cekrambut [nama]</code> → Deteksi gaya rambut secara random & lucu

Untuk hiburan saja 😄
</blockquote>
"""

GAYA_RAMBUT = [
    "lurus licin kayak iklan sampo ✨",
    "keriting mengembang kayak mie instan 🍜",
    "botak bersinar kayak bola lampu 💡",
    "belah tengah ala tahun 90an 😎",
    "poni nutup jidat kayak emo 😶‍🌫️",
    "panjang sampai menyapu lantai 🧝‍♂️",
    "acak-acakan bangun tidur 😴",
    "lepek belum keramas 😷",
    "dicat warna pelangi 🌈",
    "ada kutunya 🪳 (ups..)",
    "rambutnya palsu alias wig 🤐",
    "klimis kayak mafia 🕶️",
]

@PY.UBOT("cekrambut")
@PY.TOP_CMD
async def cek_rambut(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<b>⚠️ Gunakan format: .cekrambut [nama]</b>")

    nama = args[1]
    rambut = random.choice(GAYA_RAMBUT)

    hasil = f"""<b>
    🔍 HASIL CEK RAMBUT UNTUK {nama}
    ╭──────────────────────
    ├ 🧑 Nama  : {nama}
    ├ 💇 Rambut: {rambut}
    ╰──────────────────────
    🔁 Jangan dianggap serius ya 😅
    </b>"""
    await message.reply_text(hasil)