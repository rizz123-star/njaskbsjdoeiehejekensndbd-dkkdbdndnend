import os
import aiohttp
import zipfile
import shutil
from pyrogram import Client, filters
from PyroUbot import PY
from random import randint
from urllib.parse import urlparse

__MODULE__ = "ɢɪᴛᴄʟᴏɴᴇ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Git Clone</b>

Perintah:
<code>.gitclone [link GitHub] atau reply link GitHub</code>

Untuk Ubah Repo Github Menjadi File
</blockquote>
"""

@PY.UBOT("gitclone")
@PY.TOP_CMD
async def gitclone_handler(client, message):
    # Ambil link dari argumen atau reply
    if len(message.command) > 1:
        url = message.command[1]
    elif message.reply_to_message and message.reply_to_message.text:
        url = message.reply_to_message.text.strip()
    else:
        return await message.reply("❌ Masukkan 1 link GitHub atau reply pesan berisi link.")

    if "github.com" not in url:
        return await message.reply("❌ Link tidak valid. Harus mengandung github.com")

    parsed = urlparse(url)
    parts = parsed.path.strip("/").split("/")
    temp_dir = f"temp_gitclone_{randint(1000,9999)}"
    os.makedirs(temp_dir, exist_ok=True)
    msg = await message.reply("🔄 Memproses...")

    try:
        # ========== HANDLE REPO ========== #
        if len(parts) == 2:
            repo_user, repo_name = parts
            folder_name = f"{repo_user}-{repo_name}"
            full_path = os.path.join(temp_dir, folder_name)
            os.system(f"git clone --depth=1 https://github.com/{repo_user}/{repo_name}.git {full_path}")
            shutil.rmtree(os.path.join(full_path, ".git"), ignore_errors=True)
            info = f"✅ Berhasil clone repo:\n{repo_user}/{repo_name}"

        # ========== HANDLE FILE ========== #
        elif "blob" in parts:
            repo_user, repo_name, _, branch, *filepath = parts
            raw_url = f"https://raw.githubusercontent.com/{repo_user}/{repo_name}/{branch}/{'/'.join(filepath)}"
            file_name = filepath[-1]
            file_path = os.path.join(temp_dir, file_name)

            async with aiohttp.ClientSession() as session:
                async with session.get(raw_url) as resp:
                    if resp.status != 200:
                        return await msg.edit("❌ Gagal mengunduh file. Pastikan link valid.")
                    content = await resp.read()
                    with open(file_path, "wb") as f:
                        f.write(content)

            info = f"✅ Berhasil unduh file:\n{repo_user}/{repo_name}/{'/'.join(filepath)}"
        else:
            return await msg.edit("❌ Format link tidak dikenali.")

        # Buat ZIP
        zipname = f"Export-{repo_user}-{repo_name}.zip"
        zip_path = os.path.join(temp_dir, "..", zipname)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    arcname = os.path.relpath(full_path, temp_dir)
                    zipf.write(full_path, arcname=arcname)

        await message.reply_document(
            document=zip_path,
            caption=f"{info}\n📁 File ZIP: {zipname}",
            quote=True
        )

    except Exception as e:
        await msg.edit(f"❌ Terjadi error:\n{e}")
    finally:
        await msg.delete()
        shutil.rmtree(temp_dir, ignore_errors=True)
        if os.path.exists(zip_path):
            os.remove(zip_path)