import random
from pyrogram import *
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴄᴇᴋ ʀᴜᴍᴀʜ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Cek Rumah</b>

Perintah:
<code>{0}cekrumah [nama]</code> → DETEKSI TIPE RUMAH DARI NAMA  

Sumber: Random generator berdasarkan nama.</blockquote></b>
"""

RUMAH_LIST = [
    "RUMAH SUSUN", "KONTRAKAN", "ISTANA", "KOLONG JEMBATAN", "APARTEMEN", "RUMAH HANTU",
    "PONDOK BAMBU", "VILLA MEWAH", "KOS-KOSAN", "RUMAH BU NYAI", "GUBUK DERITA", "MARKAS AVENGERS",
]

@PY.UBOT("cekrumah")
@PY.TOP_CMD
async def cek_rumah(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<blockquote><b>⚠️ Gunakan format: .cekrumah [nama]</b></blockquote>")

    nama = args[1]
    rumah = random.choice(RUMAH_LIST)
    hasil = f'''<blockquote><b>
    HASIL DETEKSI TIPE RUMAH DARI {nama}
    ╭───────────────────────
    ├ ɴᴀᴍᴀ  : `{nama}`
    ├ ʀᴜᴍᴀʜ : `{rumah}`
    ├ sᴇʟᴀᴍᴀᴛ ʏᴀ ʀᴜᴍᴀʜɴʏᴀ sᴏғᴀʟ sᴏғᴛ 😁
    ╰────────────────────────
    ɴᴏᴛᴇ: ɪɴɪ ʜᴀɴʏᴀ ʙᴇᴄᴀɴᴅᴀ ʙʀᴏ, ᴊᴀɴɢᴀɴ ʙᴀᴡᴀ ᴘᴇʀᴀsᴀᴀɴ 😎
    </b></blockquote>'''
    await message.reply_text(hasil)