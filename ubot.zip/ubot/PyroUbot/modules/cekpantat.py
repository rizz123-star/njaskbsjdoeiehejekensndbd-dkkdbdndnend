import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴄᴇᴋ ᴘᴀɴᴛᴀᴛ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Cek Pantat</b>

Perintah:
<code>.cekpantat [nama]</code> → DETEKSI PANTAT BERDASARKAN NAMA  

Hasil acak untuk hiburan semata.</blockquote></b>
"""

BENTUK_PANTAT = [
    "bulat dan kencang 🍑",
    "lebar dan empuk 🍞",
    "rata kayak papan 🪵",
    "berotot kek batu 🧱",
    "imut dan kecil 🐭",
    "menggoda iman 😳",
    "berbulu halus 🐇",
    "kayak bantal empuk 🛏️",
    "kayak marshmallow 🍥",
    "agak penyok sebelah 😅",
]

@PY.UBOT("cekpantat")
@PY.TOP_CMD
async def cek_pantat(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<b>⚠️ Gunakan format: .cekpantat [nama]</b>")

    nama = args[1]
    pantat = random.choice(BENTUK_PANTAT)

    hasil = f"""<b>
    HASIL DETEKSI PANTAT DARI {nama}
    ╭──────────────────────
    ├ 👤 Nama : {nama}
    ├ 🍑 Pantat: {pantat}
    ╰──────────────────────
    📝 Note: Jangan baper ya, ini cuma lucu-lucuan 😁
    </b>"""
    await message.reply_text(hasil)