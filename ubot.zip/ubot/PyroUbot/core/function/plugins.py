import importlib
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from PyroUbot import bot, ubot
from PyroUbot.core.helpers import PY
from PyroUbot.modules import loadModule
from PyroUbot.core.database import *
from PyroUbot.config import OWNER_ID
from platform import python_version
from pyrogram import __version__

HELP_COMMANDS = {}

async def loadPlugins():
    modules = loadModule()
    for mod in modules:
        imported_module = importlib.import_module(f"PyroUbot.modules.{mod}")
        module_name = getattr(imported_module, "__MODULE__", "").replace(" ", "_").lower()
        if module_name:
            HELP_COMMANDS[module_name] = imported_module

    print(f"[🤖 USERBOT BY RIZZTZY🤖] [💦 TELAH BERHASIL DIAKTIFKAN! 💦]")

    await bot.send_photo(
    chat_id=OWNER_ID,
    photo="https://files.catbox.moe/x971ly.jpg",
    caption = f"""
<b>✨ ʀɪᴢᴢᴛᴢʏ ᴜꜱᴇʀʙᴏᴛ ᴀᴋᴛɪꜰ ✨</b>
<code>━━━━━━━━━━━━━━━━━━━━━━━</code>

<b>📁 Modules</b>  : <code>{len(HELP_COMMANDS)}</code>
<b>🐍 Python</b>   : <code>{python_version()}</code>
<b>📦 Pyrogram</b> : <code>{__version__}</code>
<b>🤖 Userbot</b>  : <code>{len(ubot._ubot)}</code>

<code>━━━━━━━━━━━━━━━━━━━━━━━</code>
<b>👑 Powered by: RIZZTZY</b>
""",
    
    reply_markup=InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("📋 List Userbot", callback_data="cek_ubot")],
        ]
    )
)

@PY.CALLBACK("0_cls")
async def _(client, callback_query):
    await callback_query.message.delete()