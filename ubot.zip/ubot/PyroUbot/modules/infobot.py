import asyncio
from pyrogram import Client, filters

# Informasi modul
__MODULE__ = "info bot"
__HELP__ = """
<b>Bolt Xtreme 

⎆ rizzx ubot, gugu gaga😹
"""
