import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴄᴇᴋ ʙɪʙɪʀ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Cek Bibir</b>

Perintah:
<code>{0}cekbibir [nama]</code> → Mendeteksi bentuk dan warna bibir dari nama.

Sumber: Random generator, hanya untuk hiburan 😁
</blockquote></b>
"""

BIBIR_BENTUK = [
    "tipis menggoda", "tebal sensual", "simetris indah", "bergelombang alami",
    "imut kayak permen", "mengkilap alami", "seksi banget", "biasa aja", "lucu dan unik"
]

BIBIR_WARNA = [
    "merah merona", "pink lembut", "coklat natural", "ungu gelap",
    "orange segar", "hitam misterius", "peachy", "nude elegan"
]

@PY.UBOT("cekbibir")
@PY.TOP_CMD
async def cek_bibir(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<blockquote><b>⚠️ Gunakan format: .cekbibir [nama]</b></blockquote>")

    nama = args[1]
    bentuk = random.choice(BIBIR_BENTUK)
    warna = random.choice(BIBIR_WARNA)
    
    hasil = f"""<blockquote><b>
    HASIL CEK BIBIR UNTUK {nama.upper()}
    ╭───────────────────────
    ├ ɴᴀᴍᴀ   : `{nama}`
    ├ ʙᴇɴᴛᴜᴋ : `{bentuk}`
    ├ ᴡᴀʀɴᴀ  : `{warna}`
    ╰────────────────────────
    ɴᴏᴛᴇ: ʜᴀɴʏᴀ ᴄᴀɴᴅᴀᴀɴ, ɢᴀ ᴜsᴀʜ ʙᴀᴡᴀ ᴘᴇʀᴀsᴀᴀɴ 😁
    </b></blockquote>"""

    await message.reply_text(hasil)