import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴄᴇᴋ ᴘᴇɴᴛɪʟ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Cek Pentil</b>

Perintah:
<code>{0}cekpentil [nama]</code> → Mendeteksi bentuk dan warna pentil dari nama.

Sumber: Random generator, hanya untuk bercanda 😁
</blockquote></b>
"""

PENTIL_BENTUK = [
    "bulat sempurna", "lonjong", "kecil mungil", "besar menggoda",
    "agak pipih", "kayak tombol lift", "menonjol", "rata", "unik"
]

PENTIL_WARNA = [
    "pink", "coklat muda", "coklat tua", "hitam", "merah muda", "ungu", "abu-abu", "oranye"
]

@PY.UBOT("cekpentil")
@PY.TOP_CMD
async def cek_pentil(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<blockquote><b>⚠️ Gunakan format: .cekpentil [nama]</b></blockquote>")

    nama = args[1]
    bentuk = random.choice(PENTIL_BENTUK)
    warna = random.choice(PENTIL_WARNA)
    
    hasil = f"""<blockquote><b>
    HASIL CEK PENTIL UNTUK {nama.upper()}
    ╭───────────────────────
    ├ ɴᴀᴍᴀ   : `{nama}`
    ├ ʙᴇɴᴛᴜᴋ : `{bentuk}`
    ├ ᴡᴀʀɴᴀ  : `{warna}`
    ╰────────────────────────
    ɴᴏᴛᴇ: ɪɴɪ ʜᴀɴʏᴀ ʙᴇᴄᴀɴᴅᴀ ʏᴀ ᴋᴀᴡᴀɴ 😁
    </b></blockquote>"""
    
    await message.reply_text(hasil)