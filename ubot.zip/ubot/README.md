## Rizz Userbot
```
apt update && apt upgrade -y
```
```
cd imperior
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv venv && source venv/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S imperior
```
```
npm install -g uglify-js
```
```
pip install speedtest-cli && pip install qrcode[pil] && pip install geopy && pip install pytimeparse
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd imperior
```
```
python3 -m venv venv && source venv/bin/activate
```
```
screen -S imperior
```
```
python3 -m PyroUbot
```
