import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴢᴏᴅɪᴀᴋ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Zodiak</b>

Perintah:
<code>.zodiak [nama]</code> → Menampilkan zodiak dan artinya berdasarkan nama (acak).

Sumber: Random generator, hanya untuk hiburan 😁
</blockquote>
"""

ZODIAK_LIST = [
    ("Aries", "Pemimpin alami, berani, impulsif dan penuh semangat."),
    ("Taurus", "Stabil, sabar, pecinta keindahan dan setia."),
    ("Gemini", "Cerdas, komunikatif, suka perubahan dan sangat aktif."),
    ("Cancer", "Peka, penyayang, emosional tapi penuh perhatian."),
    ("Leo", "Percaya diri, karismatik, suka jadi pusat perhatian."),
    ("Virgo", "Perfeksionis, analitis, rapi, dan perhatian pada detail."),
    ("Libra", "Penuh keadilan, seimbang, romantis dan penyuka kedamaian."),
    ("Scorpio", "Misterius, kuat, penuh gairah dan sangat setia."),
    ("Sagittarius", "Petualang, optimis, jujur dan suka kebebasan."),
    ("Capricorn", "Pekerja keras, ambisius, realistis dan disiplin."),
    ("Aquarius", "Unik, visioner, bebas dan pemikir masa depan."),
    ("Pisces", "Peka, imajinatif, penuh kasih dan penyayang.")
]

@PY.UBOT("zodiak")
@PY.TOP_CMD
async def zodiak_nama(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<b>⚠️ Gunakan format: .zodiak [nama]</b>")

    nama = args[1].strip().title()
    zodiak, arti = random.choice(ZODIAK_LIST)

    teks = f"""<b>🔮 Hasil Zodiak Untuk {nama}</b>
    
🪐 Zodiak: <b>{zodiak}</b>
📝 Arti: {arti}

<i>Note: Ini hanya ramalan acak untuk hiburan semata 😁</i>"""

    await message.reply_text(teks)