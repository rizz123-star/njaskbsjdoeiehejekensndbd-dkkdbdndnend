import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴋᴀᴘᴀɴ ᴍᴀᴛɪ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Kapan Mati</b>

Perintah:
<code>{0}kapanmati [nama]</code> → Memprediksi kapan kamu akan mati (hiburan saja).

Sumber: Random generator, jangan dianggap serius 😁
</blockquote></b>
"""

TAHUN = list(range(2025, 2100))
ALASAN = [
    "karena terlalu banyak rebahan", "karena cinta tak direstui",
    "gara-gara makan mie terus", "terlalu ganteng/cantik", 
    "dikejar utang", "gara-gara main Telegram terus", 
    "kebanyakan ngoding bug", "karena ketawa nggak berhenti", 
    "gara-gara mantan balik", "gara-gara kepo mulu"
]

@PY.UBOT("kapanmati")
@PY.TOP_CMD
async def kapan_mati(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<blockquote><b>⚠️ Gunakan format: .kapanmati [nama]</b></blockquote>")
    
    nama = args[1]
    tahun = random.choice(TAHUN)
    alasan = random.choice(ALASAN)

    hasil = f"""<blockquote><b>
    HASIL PREDIKSI KEMATIAN UNTUK {nama.upper()}
    ╭─────────────────────────────
    ├ ɴᴀᴍᴀ   : `{nama}`
    ├ ᴛᴀʜᴜɴ ᴍᴀᴛɪ : `{tahun}`
    ├ ᴀʟᴀsᴀɴ    : `{alasan}`
    ╰─────────────────────────────
    ɴᴏᴛᴇ: ɪɴɪ ʜᴀɴʏᴀ ᴄᴀɴᴅᴀᴀɴ, ᴛᴀᴋ ᴜsᴀʜ ᴅɪᴀᴍʙɪʟ ʜᴀᴛɪ 😄
    </b></blockquote>"""

    await message.reply_text(hasil)