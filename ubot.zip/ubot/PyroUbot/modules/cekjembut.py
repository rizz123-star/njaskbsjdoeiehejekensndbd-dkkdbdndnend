import random
from pyrogram import Client, filters
from PyroUbot import PY

__MODULE__ = "ᴄᴇᴋ ᴊᴇᴍʙᴜᴛ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Cek Jembut</b>

Perintah:
<code>{0}cekjembut [nama]</code> → DETEKSI JEMBUT PANJANG & WARNA  

Sumber: Random generator bercanda.</blockquote></b>
"""

PANJANG_LIST = [
    "1 cm", "3 cm", "5 cm", "8 cm", "10 cm", "12 cm", "15 cm", "20 cm", "30 cm", "50 cm", "99 cm (rambut naga)",
]

WARNA_LIST = [
    "hitam", "coklat", "pirang", "abu-abu", "merah", "biru", "ungu", "hijau", "pink", "silver", "pelangi 🌈",
]

@PY.UBOT("cekjembut")
@PY.TOP_CMD
async def cek_jembut(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<blockquote><b>⚠️ Gunakan format: .cekjembut [nama]</b></blockquote>")

    nama = args[1]
    panjang = random.choice(PANJANG_LIST)
    warna = random.choice(WARNA_LIST)
    
    hasil = f"""<blockquote><b>
HASIL CEK JEMBUT UNTUK {nama}
╭──────────────────────
├ ɴᴀᴍᴀ     : `{nama}`
├ ᴘᴀɴᴊᴀɴɢ  : `{panjang}`
├ ᴡᴀʀɴᴀ    : `{warna}`
╰──────────────────────
ɴᴏᴛᴇ: ᴊᴀɴɢᴀɴ ᴛᴀᴋᴜᴛ ʏᴀ, ɪɴɪ ᴄᴜᴍᴀ ʙᴇᴄᴀɴᴅᴀ 😁
</b></blockquote>"""
    await message.reply_text(hasil)